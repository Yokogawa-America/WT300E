//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WT300Demo.rc
//
#define IDI_ICON                        102
#define IDS_ABOUTBOX                    103
#define IDS_STRING105                   105
#define IDR_MAINFRAME                   128
#define IDD_MAIN_DIALOG                 129
#define IDD_COMM_DIALOG                 130
#define IDC_RADIO_GPIB                  1020
#define IDC_RADIO_ETHER                 1021
#define IDC_RADIO_RS232                 1022
#define IDC_RADIO_USB                   1023
#define IDC_SERIALNO                    1082
#define IDC_BTN_SEARCH_IP               1083
#define IDC_BTN_SEARCH_SERIAL           1084
#define IDC_COMBO_SERIALNO              1085
#define IDC_CMBBOX_IP                   1086
#define IDC_COMBO_IP                    1086
#define IDC_COMBO_ADDR                  1101
#define IDC_EDIT_IP                     1201
#define IDC_EDIT_USER                   1202
#define IDC_EDIT_PWD                    1203
#define IDC_COMBO_PORT                  1301
#define IDC_COMBO_BAUD                  1302
#define IDC_COMBO_FORMAT                1303
#define IDC_COMBO_HDSHK                 1304
#define IDC_COMBO_TMNTR                 1305
#define IDC_COMBO_USBADDR               1402
#define IDC_RADIO_E1                    2021
#define IDC_RADIO_E2                    2022
#define IDC_RADIO_E3                    2023
#define IDC_RADIO_E4                    2024
#define IDC_RADIO_E5                    2025
#define IDC_RADIO_E6                    2026
#define IDC_COMBOV                      2030
#define IDC_COMBOC                      2031
#define IDC_BUTTON_SETRANGE             2039
#define IDC_COMBOR                      2040
#define IDC_BUTTON_SETRATE              2049
#define IDC_EDIT_TEST                   2060
#define IDC_BUTTON_SENDCMD              2061
#define IDC_EDIT_ERR                    2062
#define IDC_BUTTON_GETERR               2063
#define IDC_BUTTON_RST                  2099
#define IDC_RADIO_ASC                   2105
#define IDC_RADIO_BIN                   2106
#define IDC_COMBO_ITEMS                 2110
#define IDC_BUTTON_GETITEMS             2120
#define IDC_BUTTON_SETITEMS             2121
#define IDC_COMBO_F1                    2201
#define IDC_COMBO_F2                    2202
#define IDC_COMBO_F3                    2203
#define IDC_COMBO_F4                    2204
#define IDC_COMBO_F5                    2205
#define IDC_COMBO_F6                    2206
#define IDC_COMBO_F7                    2207
#define IDC_COMBO_F8                    2208
#define IDC_COMBO_F9                    2209
#define IDC_COMBO_F10                   2210
#define IDC_COMBO_E1                    2211
#define IDC_COMBO_E2                    2212
#define IDC_COMBO_E3                    2213
#define IDC_COMBO_E4                    2214
#define IDC_COMBO_E5                    2215
#define IDC_COMBO_E6                    2216
#define IDC_COMBO_E7                    2217
#define IDC_COMBO_E8                    2218
#define IDC_COMBO_E9                    2219
#define IDC_COMBO_E10                   2220
#define IDC_COMBO_O1                    2221
#define IDC_COMBO_O2                    2222
#define IDC_COMBO_O3                    2223
#define IDC_COMBO_O4                    2224
#define IDC_COMBO_O5                    2225
#define IDC_COMBO_O6                    2226
#define IDC_COMBO_O7                    2227
#define IDC_COMBO_O8                    2228
#define IDC_COMBO_O9                    2229
#define IDC_COMBO_O10                   2230
#define IDC_EDIT_D1                     2231
#define IDC_EDIT_D2                     2232
#define IDC_EDIT_D3                     2233
#define IDC_EDIT_D4                     2234
#define IDC_EDIT_D5                     2235
#define IDC_EDIT_D6                     2236
#define IDC_EDIT_D7                     2237
#define IDC_EDIT_D8                     2238
#define IDC_EDIT_D9                     2239
#define IDC_EDIT_D10                    2240
#define IDC_BUTTON_GETDATA_T            2251
#define IDC_EDIT_TMR                    2252
#define IDC_BUTTON_GETDATA_R            2253
#define IDC_BUTTON_GETDATA_S            2255
#define IDC_CHECK_SAVE                  2256
#define IDC_EDIT_FILE                   2257
#define IDC_EDIT_SEND                   2310
#define IDC_BUTTON_RCLR                 2311
#define IDC_EDIT_RCV                    2312
#define IDC_BUTTON_SCLR                 2313
#define IDC_BUTTON_HEADER               2320
#define IDC_BUTTON_VERBOSE              2321
#define IDC_MODEL_EDIT                  2330

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1087
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
