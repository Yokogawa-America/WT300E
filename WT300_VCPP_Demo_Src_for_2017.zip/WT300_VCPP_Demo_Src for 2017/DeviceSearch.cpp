/*==========================================================
 Copyright (C) 2013 YOKOGAWA ELECTRIC CORPORATION

    ALL RIGHTS RESERVED BY YOKOGAWA ELECTRIC CORPORATION.
THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT
WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY
AND/OR FITNESS FOR A PARTICULAR PURPOSE.

                            YOKOGAWA ELECTRIC CORPORATION
==========================================================*/
//DeviceSearch.cpp

#include "stdafx.h"

#include "DeviceSearch.h"
#include "CommDialog.h"
#include <winsock2.h>
#include <ws2tcpip.h>
#define _WINSOCK_DEPRECATED_NO_WARNINGS

DeviceSearch::DeviceSearch(void){}
DeviceSearch::~DeviceSearch(void){}

int DeviceSearch::SearchUSBSerial( int* DeviceCnt, DEVICELIST DeviceList[] )
{
	DEVICELIST	listbuff[127] ;
	int		i;
	int		num;
	int		ret;
	char	decode[64] ;
	
#ifndef _OLDTMCTL
	ret = TmcSearchDevices(TM_CTL_USBTMC2, listbuff, 127, &num, NULL);
#else
	//DEVICELISTEX listbuffEx[127];
	//ret = TmcSearchDevicesEx(TM_CTL_USBTMC2, listbuffEx, 127, &num, NULL);

	//int max = num;
	//memset(listbuff, 0, sizeof(DEVICELIST) * 127);

	//// devlist���l�߂�
	//int count = 0;
	//for (int i = 0; i < max; i++) {
	//	if (listbuffEx[i].adr[0] != NULL)
	//		memcpy(&listbuff[count++].adr[0], &listbuffEx[i].adr[0], ADRMAXLEN);
	//}
#endif // _OLDTMCTL

	if(ret != 0)
		return false;
	else
	{
		for( i = 0; i < num; i++)
		{
			ret = Check_WTSeries(TM_CTL_USBTMC2,listbuff[i].adr);
			if (ret == 0)
			{
				ret = TmcDecodeSerialNumber(decode,64,listbuff[i].adr);
				if(ret == 0){
					memcpy(DeviceList[*DeviceCnt].adr , decode , sizeof(decode));
					*DeviceCnt += 1;
				}
			}
		}
	}
	return true;
}

int DeviceSearch::SearchEtherAddress( int* DeviceCnt, DEVICELIST DeviceList[] )
{
	DEVICELIST	listbuff[127] ;
	int		i;
	int		num;
	int		ret;
	CString	strbuff;

	ret = TmcSearchDevices(TM_CTL_VXI11,listbuff,127,&num,NULL/*maskopt*/);
	if(ret != 0)
		return false;
	else
	{
		for( i = 0; i < num; i++)
		{
			ret = Check_WTSeries(TM_CTL_VXI11,listbuff[i].adr);
			if (ret == 0)
			{
				DeviceList[*DeviceCnt]=listbuff[i];
				*DeviceCnt += 1;
			}
		}
	}
	return true;
}

int DeviceSearch::Check_WTSeries(int wire,char* addr)
{
	CString m_sAddr = addr;
	CString m_sName;
	int ret;
	int		m_iID;

	ret = TmcInitialize(wire, m_sAddr.GetBuffer(0), &m_iID);
	if(ret != 0)
	{
		return ret;
	}
	//tmcsetterm
	ret = TmcSetTerm(m_iID, 2, 1);
	if(ret != 0)
	{
		TmcFinish(m_iID);
		return ret;
	}
	//tmcsettimeout(1*100ms)
	ret = TmcSetTimeout(m_iID, 1);
	if(ret != 0)
	{
		TmcFinish(m_iID);
		return ret;
	}
	//test the device module connected.
	ret = TmcSend(m_iID, "*IDN?");
	int maxLength = 256;
	char* buf ;
	if ((buf = new char[maxLength]) == NULL)
	{
		TmcSetTimeout( m_iID, 20 );
		TmcFinish(m_iID);
		return 1;
	}
	memset(buf,0,maxLength);
	int realLength;
	ret = TmcReceive(m_iID, buf, maxLength, &realLength);
	m_sName.Format("%s", buf);
	delete[] buf;
	if(ret != 0)
	{
		TmcFinish(m_iID);
	}
	ret = m_sName.Find("WT3",0);
	if(ret == -1)
	{
		ret = 1;
	}
	else{
		ret = 0;
	}
	TmcSetTimeout( m_iID, 20 );
	TmcFinish(m_iID);
	return ret;
}
