/*==========================================================
 Copyright (C) 2005 YOKOGAWA ELECTRIC CORPORATION

    ALL RIGHTS RESERVED BY YOKOGAWA ELECTRIC CORPORATION.
THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT
WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY
AND/OR FITNESS FOR A PARTICULAR PURPOSE.

                            YOKOGAWA ELECTRIC CORPORATION
==========================================================*/
// WT300Demo.cpp

#include "stdafx.h"
#include "WT300Demo.h"
#include "CommDialog.h"
#include "MainDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWT300DemoApp

BEGIN_MESSAGE_MAP(CWT300DemoApp, CWinApp)
	//{{AFX_MSG_MAP(CWT300DemoApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWT300DemoApp instructor

CWT300DemoApp::CWT300DemoApp()
{
}

/////////////////////////////////////////////////////////////////////////////
//CWT300DemoApp object

CWT300DemoApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CWT300DemoApp initialize

BOOL CWT300DemoApp::InitInstance()
{
	AfxEnableControlContainer();

#ifdef _AFXDLL
//	Enable3dControls();
#else
	Enable3dControlsStatic();
#endif
	CCommDialog commDlg;
	int nResponse = commDlg.DoModal();
    if (nResponse != IDOK)
	{
		return false;
	}
	CMainDialog mainDlg;
	nResponse = mainDlg.DoModal();
	return false;
}
