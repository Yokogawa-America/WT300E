/*==========================================================
 Copyright (C) 2013 YOKOGAWA ELECTRIC CORPORATION

    ALL RIGHTS RESERVED BY YOKOGAWA ELECTRIC CORPORATION.
THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT
WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY
AND/OR FITNESS FOR A PARTICULAR PURPOSE.

                            YOKOGAWA ELECTRIC CORPORATION
==========================================================*/
//DeviceSearch.h

#pragma once

#include "tmctl.h"

class DeviceSearch
{
public:
	DeviceSearch(void);
	~DeviceSearch(void);

	struct IPINFO{
		DWORD	ipAddress;
		DWORD	netMask;
	};

public:
	/* Check WTSeries */
	int DeviceSearch::Check_WTSeries(int wire,char* addr);
	/* SearchDevice : USB */
	int DeviceSearch::SearchUSBSerial(int* DeviceCnt, DEVICELIST* DeviceList);
	/* SearchDevice : Ether */
	int DeviceSearch::SearchEtherAddress(int* DeviceCnt, DEVICELIST* DeviceList);


};
