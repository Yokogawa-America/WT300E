/*==========================================================
 Copyright (C) 2005 YOKOGAWA ELECTRIC CORPORATION

    ALL RIGHTS RESERVED BY YOKOGAWA ELECTRIC CORPORATION.
THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT
WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY
AND/OR FITNESS FOR A PARTICULAR PURPOSE.

                            YOKOGAWA ELECTRIC CORPORATION
==========================================================*/
// MainDialog.cpp

#include "stdafx.h"
#include "WT300Demo.h"
#include "MainDialog.h"
#include "CommDialog.h"
#include "Connection.h"
//#include <fstream.h>
using namespace std;
#include <fstream>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//##########################################//
// CMainDialog
//##########################################//
const int MAX_ITEM    = 10;       //the max items count.
const int MAX_ELEMENT = 3;        //the max elements count.
const int MAX_LINES   = 100;      //the max monitor lines count.
const int TIMER_1     = 1;        //used when getting data by update rate.
const int TIMER_2     = 2;        //used when getting data by timer.
/* function */
const int MAX_FUNCTION          = 39;
const int NORMAL_FUNCTION_TOP   = 0;
const int NORMAL_FUNCTION_BOTTOM= 25;
const int HARM_FUNCTION_TOP     = 26;
const int HARM_FUNCTION_BOTTOM  = 38;
const int MAX_ORDER             = 50;
/* CurrentRange */
const int WT310_CURRENT_TOP     = 0;
const int WT310_CURRENT_BOTTM   = 11;
const int WT310HC_CURRENT_TOP   = 7;
const int WT310HC_CURRENT_BOTTM = 12;
const int WT330_CURRENT_TOP     = 6;
const int WT330_CURRENT_BOTTM   = 11;
const int EX1_CURRENT_TOP       = 6;
const int EX1_CURRENT_BOTTM     = 8;
const int EX2_CURRENT_TOP       = 0;
const int EX2_CURRENT_BOTTM     = 5;
/* CrestFactor */
const int CF_3 = 0;
const int CF_6 = 1;
/* external sensor range Option */
const int EX1 = 1;
const int EX2 = 2;

CMainDialog::CMainDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMainDialog::IDD, pParent)
{
	HarmonicOption=-1;
	ExtOption=-1;
	currenttop=0;
	currentbottom=0;
	extcurrtop=0;
	extcurrbottom=0;
	for(int i=0; i<9; i++)
		oldFuncName[i] = _T("U");
	//{{AFX_DATA_INIT(CMainDialog)
	m_sEditTest = _T("");
	m_sEditSend = _T("");
	m_sEditRcv = _T("");
	m_sEditError = _T("");
	m_sFileName = _T("");
	m_iRadioElement = -1;
	m_sComboItems = _T("");
	//}}AFX_DATA_INIT
}

void CMainDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMainDialog)
	DDX_Control(pDX, IDC_COMBO_F9, m_combo_f9);
	DDX_Control(pDX, IDC_COMBO_F8, m_combo_f8);
	DDX_Control(pDX, IDC_COMBO_F7, m_combo_f7);
	DDX_Control(pDX, IDC_COMBO_F6, m_combo_f6);
	DDX_Control(pDX, IDC_COMBO_F5, m_combo_f5);
	DDX_Control(pDX, IDC_COMBO_F4, m_combo_f4);
	DDX_Control(pDX, IDC_COMBO_F3, m_combo_f3);
	DDX_Control(pDX, IDC_COMBO_F10, m_combo_f10);
	DDX_Control(pDX, IDC_COMBO_F1, m_combo_f1);
	DDX_Control(pDX, IDC_COMBO_F2, m_combo_f2);
	DDX_Control(pDX, IDC_COMBOR, m_comboR);
	DDX_Control(pDX, IDC_COMBOV, m_comboU);
	DDX_Control(pDX, IDC_COMBOC, m_comboI);
	DDX_Text(pDX, IDC_EDIT_TEST, m_sEditTest);
	DDX_Text(pDX, IDC_EDIT_SEND, m_sEditSend);
	DDX_Text(pDX, IDC_EDIT_RCV, m_sEditRcv);
	DDX_Text(pDX, IDC_EDIT_ERR, m_sEditError);
	DDX_Text(pDX, IDC_EDIT_FILE, m_sFileName);
	DDX_CBString(pDX, IDC_COMBO_ITEMS, m_sComboItems);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMainDialog, CDialog)
	//{{AFX_MSG_MAP(CMainDialog)
	ON_BN_CLICKED(IDC_BUTTON_SETRANGE, OnButtonSetRange)
	ON_BN_CLICKED(IDC_BUTTON_SENDCMD, OnButtonSendCmd)
	ON_CBN_SELCHANGE(IDC_COMBO_ITEMS, OnSelchangeComboItems)
	ON_BN_CLICKED(IDC_BUTTON_GETITEMS, OnButtonGetItems)
	ON_BN_CLICKED(IDC_BUTTON_SETRATE, OnButtonSetRate)
	ON_BN_CLICKED(IDC_BUTTON_SETITEMS, OnButtonSetItems)
	ON_BN_CLICKED(IDC_BUTTON_GETDATA_S, OnButtonGetDataS)
	ON_BN_CLICKED(IDC_BUTTON_GETDATA_R, OnButtonGetDataR)
	ON_BN_CLICKED(IDC_BUTTON_GETDATA_T, OnButtonGetDataT)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_CHECK_SAVE, OnCheckSave)
	ON_BN_CLICKED(IDC_BUTTON_SCLR, OnButtonSclr)
	ON_BN_CLICKED(IDC_BUTTON_RCLR, OnButtonRclr)
	ON_BN_CLICKED(IDC_BUTTON_GETERR, OnButtonGetError)
	ON_BN_CLICKED(IDC_BUTTON_HEADER, OnButtonHeader)
	ON_BN_CLICKED(IDC_BUTTON_RST, OnButtonRst)
	ON_BN_CLICKED(IDCLOSE, OnDlgClose)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BUTTON_VERBOSE, OnButtonVerbose)
	ON_CBN_SELCHANGE(IDC_COMBO_F2, OnSelchangeComboF2)
	ON_CBN_SELCHANGE(IDC_COMBO_F3, OnSelchangeComboF3)
	ON_CBN_SELCHANGE(IDC_COMBO_F4, OnSelchangeComboF4)
	ON_CBN_SELCHANGE(IDC_COMBO_F5, OnSelchangeComboF5)
	ON_CBN_SELCHANGE(IDC_COMBO_F6, OnSelchangeComboF6)
	ON_CBN_SELCHANGE(IDC_COMBO_F7, OnSelchangeComboF7)
	ON_CBN_SELCHANGE(IDC_COMBO_F8, OnSelchangeComboF8)
	ON_CBN_SELCHANGE(IDC_COMBO_F9, OnSelchangeComboF9)
	ON_CBN_SELCHANGE(IDC_COMBO_F10, OnSelchangeComboF10)
	ON_CBN_SELCHANGE(IDC_COMBO_F1, OnSelchangeComboF1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//==========================================//
///<summary>
///Function: ConstInit
///</summary>
//==========================================//
void CMainDialog::InitListItem()
{
    //===========================
    ///Error Code from Tmctl
    //===========================
    //Error Number  Problem                                  Solutions
	errorMsg[0]  = "Device not found";            //   2  1 Check the wiring.  
	errorMsg[1]  = "Connection to device failed"; //   4  2 Check the wiring.  
	errorMsg[2]  = "Device not connected";        //   8  3 Connect the device using the initialization function.  
	errorMsg[3]  = "Device already connected";    //  16  4 Two connections cannot be opened.  
	errorMsg[4]  = "Incompatible PC";             //  32  5 Check the hardware you are using.  
	errorMsg[5]  = "Illegal parameter";           //  64  6 Check parameter type etc. 
    errorMsg[6].Empty();
	errorMsg[7]  = "Send error";                  // 256  8 Check the wiring, address, and ID.
	errorMsg[8]  = "Receive error";               // 512  9 Check whether an error occurred on the device.  
	errorMsg[9]  = "Received data not block data";//1024 10
	errorMsg[10] = "System error";                //4096 11 There is a problem with the operating environment.  
	errorMsg[11] = "Illegal device ID";           //8192 12 Use the ID of the device acquired by the initialization function.  

    //===========================
    ///UpdateRate List
    //===========================
	updateRateList[0] = "100ms";
	updateRateList[1] = "250ms";
	updateRateList[2] = "500ms";
	updateRateList[3] = "1s";
	updateRateList[4] = "2s";
	updateRateList[5] = "5s";
	updateRateList[6] = "10s";
	updateRateList[7] = "20s";
	updateRateList[8] = "AUTO";
	updateRateList[9].Empty();

    //AutoRange item
    rangeListAuto = "AUTO";
    //===========================
    ///Voltage Range List
    //===========================
    //CrestFactor = 3
	voltageList[0] [0] = "15V";
	voltageList[0] [1] = "30V";
	voltageList[0] [2] = "60V";
	voltageList[0] [3] = "150V";
	voltageList[0] [4] = "300V";
	voltageList[0] [5] = "600V";
	voltageList[0] [6].Empty();
	voltageList[0] [7].Empty();
	voltageList[0] [8].Empty();
	voltageList[0] [9].Empty();
	voltageList[0] [10].Empty();
	voltageList[0] [11].Empty();

    //CrestFactor = 6
	voltageList[1] [0] = "7.5V";
	voltageList[1] [1] = "15V";
	voltageList[1] [2] = "30V";
	voltageList[1] [3] = "75V";
	voltageList[1] [4] = "150V";
	voltageList[1] [5] = "300V";
	voltageList[1] [6].Empty();
	voltageList[1] [7].Empty();
	voltageList[1] [8].Empty();
	voltageList[1] [9].Empty();
	voltageList[1] [10].Empty();
	voltageList[1] [11].Empty();
    //===========================
    ///Current Range List
    //===========================
    //CrestFactor = 3
	currentList[0] [0] = "5mA";
	currentList[0] [1] = "10mA";
	currentList[0] [2] = "20mA";
	currentList[0] [3] = "50mA";
	currentList[0] [4] = "100mA";
	currentList[0] [5] = "200mA";
	currentList[0] [6] = "0.5A";
	currentList[0] [7]  = "1A";
	currentList[0] [8]  = "2A";
	currentList[0] [9]  = "5A";;
	currentList[0] [10] = "10A";
	currentList[0] [11] = "20A";
	currentList[0] [12] = "40A";
	currentList[0] [13].Empty();
	currentList[0] [14].Empty();
	currentList[0] [15].Empty();

    //CrestFactor = 6
	currentList[1] [0] = "2.5mA";
	currentList[1] [1] = "5mA";
	currentList[1] [2] = "10mA";
	currentList[1] [3] = "25mA";
	currentList[1] [4] = "50mA";
	currentList[1] [5] = "100mA";
	currentList[1] [6] = "0.25A";
	currentList[1] [7] = "0.5A";
	currentList[1] [8] = "1A";
	currentList[1] [9] = "2.5A";
	currentList[1] [10] = "5A";
	currentList[1] [11] = "10A";
	currentList[1] [12] = "20A";
	currentList[1] [13].Empty();
	currentList[1] [14].Empty();
	currentList[1] [15].Empty();

    //CrestFactor = 3
	extcurrList[0] [0] = "50mV";
	extcurrList[0] [1] = "100mV";
	extcurrList[0] [2] = "200mV";
	extcurrList[0] [3] = "500mV";
	extcurrList[0] [4] = "1V";
	extcurrList[0] [5] = "2V";
	extcurrList[0] [6] = "2.5V";
	extcurrList[0] [7] = "5V";
	extcurrList[0] [8] = "10V";
	extcurrList[0] [9].Empty();
	extcurrList[0] [10].Empty();
	extcurrList[0] [11].Empty();
	extcurrList[0] [12].Empty();
	extcurrList[0] [13].Empty();
	extcurrList[0] [14].Empty();
	extcurrList[0] [15].Empty();
	extcurrList[0] [16].Empty();
	extcurrList[0] [17].Empty();
	extcurrList[0] [18].Empty();

    //CrestFactor = 6
	extcurrList[1] [0] = "25mV";
	extcurrList[1] [1] = "50mV";
	extcurrList[1] [2] = "100mV";
	extcurrList[1] [3] = "250mV";
	extcurrList[1] [4] = "0.5V";
	extcurrList[1] [5] = "1V";
	extcurrList[1] [6] = "1.25V";
	extcurrList[1] [7] = "2.5V";
	extcurrList[1] [8] = "5V";
	extcurrList[1] [9].Empty();
	extcurrList[1] [10].Empty();
	extcurrList[1] [11].Empty();
	extcurrList[1] [12].Empty();
	extcurrList[1] [13].Empty();
	extcurrList[1] [14].Empty();
	extcurrList[1] [15].Empty();
	extcurrList[1] [16].Empty();
	extcurrList[1] [17].Empty();
	extcurrList[1] [18].Empty();

    //===========================
    ///Element List
    //===========================
    eList[0] = "1";
    eList[1] = "2";
    eList[2] = "3";
    eList[3] = "SIGMA";
    eList[4].Empty();
    eList[5].Empty();
    eList[6].Empty();

    //===========================
    ///Order List
    //===========================
    oList[0] = "Total";
    oList[1] = "1";
    oList[2] = "2";
    oList[3] = "3";
    oList[4] = "4";
    oList[5] = "5";
    oList[6] = "6";
    oList[7] = "7";
    oList[8] = "8";
    oList[9] = "9";
    oList[10] = "10";
    oList[11] = "11";
    oList[12] = "12";
    oList[13] = "13";
    oList[14] = "14";
    oList[15] = "15";
    oList[16] = "16";
    oList[17] = "17";
    oList[18] = "18";
    oList[19] = "19";
    oList[20] = "20";
    oList[21] = "21";
    oList[22] = "22";
    oList[23] = "23";
    oList[24] = "24";
    oList[25] = "25";
    oList[26] = "26";
    oList[27] = "27";
    oList[28] = "28";
    oList[29] = "29";
    oList[30] = "30";
    oList[31] = "31";
    oList[32] = "32";
    oList[33] = "33";
    oList[34] = "34";
    oList[35] = "35";
    oList[36] = "36";
    oList[37] = "37";
    oList[38] = "38";
    oList[39] = "39";
    oList[40] = "40";
    oList[41] = "41";
    oList[42] = "42";
    oList[43] = "43";
    oList[44] = "44";
    oList[45] = "45";
    oList[46] = "46";
    oList[47] = "47";
    oList[48] = "48";
    oList[49] = "49";
    oList[50] = "50";
    oList[51].Empty();
    oList[52].Empty();
    oList[53].Empty();
    oList[54].Empty();
    oList[55].Empty();
    oList[56].Empty();
    oList[57].Empty();
    oList[58].Empty();
    oList[59].Empty();
    oList[60].Empty();
    oList[61].Empty();
    oList[62].Empty();
    oList[63].Empty();
    oList[64].Empty();
    oList[65].Empty();
    oList[66].Empty();
    oList[67].Empty();
    oList[68].Empty();
    oList[69].Empty();
    oList[70].Empty();
    oList[71].Empty();
    oList[72].Empty();
    oList[73].Empty();
    oList[74].Empty();
    oList[75].Empty();
    oList[76].Empty();
    oList[77].Empty();
    oList[78].Empty();
    oList[79].Empty();
    oList[80].Empty();
    oList[81].Empty();
    oList[82].Empty();
    oList[83].Empty();
    oList[84].Empty();
    oList[85].Empty();
    oList[86].Empty();
    oList[87].Empty();
    oList[88].Empty();
    oList[89].Empty();
    oList[90].Empty();
    oList[91].Empty();
    oList[92].Empty();
    oList[93].Empty();
    oList[94].Empty();
    oList[95].Empty();
    oList[96].Empty();
    oList[97].Empty();
    oList[98].Empty();
    oList[99].Empty();
    oList[100].Empty();
    oList[101].Empty();
    oList[102].Empty();

	//===========================
    //     init Struct
    //===========================
    List[0].FunctionName = "NONE";
    List[0].ElementFlag  = FALSE;
    List[0].OrderFlag    = FALSE;

    List[1].FunctionName = "U";
    List[1].ElementFlag  = TRUE;
    List[1].OrderFlag    = FALSE;
         
    List[2].FunctionName = "I";
    List[2].ElementFlag  = TRUE;
    List[2].OrderFlag    = FALSE;
         
    List[3].FunctionName = "P";
    List[3].ElementFlag  = TRUE;
    List[3].OrderFlag    = FALSE;
         
    List[4].FunctionName = "S";
    List[4].ElementFlag  = TRUE;
    List[4].OrderFlag    = FALSE;
         
    List[5].FunctionName = "Q";
    List[5].ElementFlag  = TRUE;
    List[5].OrderFlag    = FALSE;
         
    List[6].FunctionName = "LAMBDA"; //"LAMBda"
    List[6].ElementFlag  = TRUE;
    List[6].OrderFlag    = FALSE;
         
    List[7].FunctionName = "PHI";
    List[7].ElementFlag  = TRUE;
    List[7].OrderFlag    = FALSE;

    List[8].FunctionName = "FU"; //"FreqU[fU]"
    List[8].ElementFlag  = TRUE;
    List[8].OrderFlag    = FALSE;
         
    List[9].FunctionName = "FI"; //"FreqI[fI]"
    List[9].ElementFlag  = TRUE;
    List[9].OrderFlag    = FALSE;
         
    List[10].FunctionName = "UPPEAK"; //"U+peak[U+peak]"
    List[10].ElementFlag  = TRUE;
    List[10].OrderFlag    = FALSE;
         
    List[11].FunctionName = "UMPEAK"; //"U-peak[U-peak]"
    List[11].ElementFlag  = TRUE;
    List[11].OrderFlag    = FALSE;
         
    List[12].FunctionName = "IPPEAK"; //"I+peak[I+peak]"
    List[12].ElementFlag  = TRUE;
    List[12].OrderFlag    = FALSE;
         
    List[13].FunctionName = "IMPEAK"; //"I-peak[I-peak]"
    List[13].ElementFlag  = TRUE;
    List[13].OrderFlag    = FALSE;
         
    List[14].FunctionName = "PPPEAK"; //"P+peak[P+peak]"
    List[14].ElementFlag  = TRUE;
    List[14].OrderFlag    = FALSE;
         
    List[15].FunctionName = "PMPEAK"; //"P-peak[P-peak]"
    List[15].ElementFlag  = TRUE;
    List[15].OrderFlag    = FALSE;
         
    List[16].FunctionName = "TIME";
    List[16].ElementFlag  = FALSE;
    List[16].OrderFlag    = FALSE;
         
    List[17].FunctionName = "WH"; //"Wp"
    List[17].ElementFlag  = TRUE;
    List[17].OrderFlag    = FALSE;
         
    List[18].FunctionName = "WHP"; //"Wp+"
    List[18].ElementFlag  = TRUE;
    List[18].OrderFlag    = FALSE;
         
	List[19].FunctionName = "WHM"; //"Wp-"
    List[19].ElementFlag  = TRUE;
    List[19].OrderFlag    = FALSE;
         
	List[20].FunctionName = "AH"; //"q"
    List[20].ElementFlag  = TRUE;
    List[20].OrderFlag    = FALSE;
         
	List[21].FunctionName = "AHP"; //"q+"
    List[21].ElementFlag  = TRUE;
    List[21].OrderFlag    = FALSE;
         
    List[22].FunctionName = "AHM"; //"q-"
    List[22].ElementFlag  = TRUE;
    List[22].OrderFlag    = FALSE;
         
    List[23].FunctionName = "MATH"; //"MATH"
    List[23].ElementFlag  = FALSE;
    List[23].OrderFlag    = FALSE;
         
    List[24].FunctionName = "URANGE"; //"URange"
    List[24].ElementFlag  = FALSE;
    List[24].OrderFlag    = FALSE;
         
    List[25].FunctionName = "IRANGE"; //"IRange"
    List[25].ElementFlag  = FALSE;
    List[25].OrderFlag    = FALSE;
         
    //---------'/G5 optional--------------
         
    List[26].FunctionName = "UK"; //"U(k)"
    List[26].ElementFlag  = TRUE;
    List[26].OrderFlag    = TRUE;
         
    List[27].FunctionName = "IK";
    List[27].ElementFlag  = TRUE;
    List[27].OrderFlag    = TRUE;
         
    List[28].FunctionName = "PK";
    List[28].ElementFlag  = TRUE;
    List[28].OrderFlag    = TRUE;
         
    List[29].FunctionName = "LAMBDAK"; //"LAMBda"
    List[29].ElementFlag  = TRUE;
    List[29].OrderFlag    = TRUE;
         
    List[30].FunctionName = "PHIK";
    List[30].ElementFlag  = TRUE;
    List[30].OrderFlag    = TRUE;
         
    List[31].FunctionName = "PHIUK";
    List[31].ElementFlag  = TRUE;
    List[31].OrderFlag    = TRUE;
         
    List[32].FunctionName = "PHIIK";
    List[32].ElementFlag  = TRUE;
    List[32].OrderFlag    = TRUE;
         
    List[33].FunctionName = "UHDFK";
    List[33].ElementFlag  = TRUE;
    List[33].OrderFlag    = TRUE;
         
    List[34].FunctionName = "IHDFK";
    List[34].ElementFlag  = TRUE;
    List[34].OrderFlag    = TRUE;
         
    List[35].FunctionName = "PHDFK";
    List[35].ElementFlag  = TRUE;
    List[35].OrderFlag    = TRUE;
         
    List[36].FunctionName = "UTHD"; //"Uthd"
    List[36].ElementFlag  = TRUE;
    List[36].OrderFlag    = FALSE;
         
    List[37].FunctionName = "ITHD"; //"Ithd"
    List[37].ElementFlag  = TRUE;
    List[37].OrderFlag    = FALSE;
         
    List[38].FunctionName = "FPLL";
    List[38].ElementFlag  = FALSE;
    List[38].OrderFlag    = FALSE;
}
// find function position in the List[] arrary
int CMainDialog::FindFunPos(CString fun)
{
	int position;
	position = -1;

	for(int i=0; i<MAX_FUNCTION; i++)
	{
		if (List[i].FunctionName == fun)
		{
			position = i;
			break;	
		}
	}
	return position;
}

//==========================================//
///Dialog Init
//==========================================//
BOOL CMainDialog::OnInitDialog() 
{
    m_hIcon = AfxGetApp()->LoadIcon(IDI_ICON);
	CDialog::OnInitDialog();
    SetIcon(m_hIcon, TRUE);
    InitListItem();
    CString Type;
	CString msg_temp;

	//Get Instrument IDN
    msg_temp="*IDN?";
    SetSendMonitor(msg_temp);
    if (!QueriesData(60, msg_temp, &Type))
    {
        return FALSE;
    }
    SetReceiveMonitor(Type);

    CWnd* pWnd;
    CString model = CConnection::m_sName;
    model = CutLeft((char)10, &model);

    //--------#set ModelType display#
    pWnd = GetDlgItem(IDC_MODEL_EDIT);
    pWnd->SetWindowText(model);

    //check model.
    CutLeft(',', &model);
    int symbol = model.Find(",");
	modelType = model.Left(symbol);
	if ( -1 == modelType.Find("WT3") )
    {
        DispError("it seems not WT300E/WT300, program may run incorrectly!");
    }
    //----------#set element#
	if( modelType == "WT333E" || modelType == "WT333" )
		lastElement = 3;
	else if( modelType == "WT332E" || modelType == "WT332" )
		lastElement = 3;
	else
		lastElement = 1;

	//----------------------#Queries the CrestFactor#
    CString value;
    CString msg = ":INPUT:CFACTOR?";
	SetSendMonitor(msg);
    if (!QueriesData(20, msg, &value))
    {
        return FALSE;
    }
	SetReceiveMonitor(value);
    crestFactor = CutLeft((char)10, &value);//cut left with LF.
	if(crestFactor == "3")
		nCrestFactor = CF_3;
	else
		nCrestFactor = CF_6;

	GetUpdateRate();
    //get current item settings from instrument.

	GetOption();
	RangeListSettings();
	ReadItemSettings();

	//Set the first RadioBox to be checked.
    GetRanges();

    pWnd = GetDlgItem(IDC_EDIT_FILE);
    pWnd->SetWindowText("MeasuredData.csv");
    pWnd->EnableWindow(FALSE);
    pWnd = GetDlgItem(IDC_EDIT_TMR);
    pWnd->SetWindowText("500");
    return TRUE;
}

//==========================================//
///Dialog Close
//==========================================//
void CMainDialog::OnClose()
{
	//close connection when exit window by system menu.
	m_connection.Finish();
	CDialog::OnClose();
}
void CMainDialog::OnDlgClose()
{
	//close connection when exit window by system menu.
	m_connection.Finish();
    CMainDialog::OnOK();
}

//==========================================//
///to get and display the given item in the list
//==========================================//
void CMainDialog::ComboListSel(CComboBox* pCombo, CString content)
{
    int n;
    CString listText;
    for (n=0; n<pCombo->GetCount(); n++)
    {
        pCombo->GetLBText(n, listText);
        if (listText == content)
        {
            pCombo->SetCurSel(n);
            break;
        }
    }
}

//==========================================//
/// <summary> Function: CutLeft </summary>
///cut the left half to outData,
///and the right portion remain in inData.
//example:
///symbol:"2", in:"12345" => out:"1", in:"345"
//==========================================//
CString CMainDialog::CutLeft(char symbol, CString* inData)
{
    CString outData = *inData;
    int pos = (*inData).Find(symbol);
    if (pos == -1)
    {
        //if no symbol, cut with LF.
        pos = (*inData).Find(10);
    }
    if (pos != -1)
    {
        outData = (*inData).Left(pos);
        *inData = (*inData).Mid(pos + 1);
    }
    //cut data when harmonics mode
    pos = outData.Find(" ");
    if (pos != -1)
    {
        outData = outData.Mid(pos + 1);
    }
    return outData;
}

//==========================================//
///<summary>Function: QueriesData</summary>
//==========================================//
bool CMainDialog::QueriesData(int maxLength, CString sMsg, CString* data)
{
    int rtn;
	//Send Command.
    rtn = m_connection.Send(sMsg);
    if (rtn != 0)
    {
	    DispError(m_connection.GetLastError());
	    return FALSE;
    }

	//Queries Data.
    int realLength;
    char* buf;
    if ((buf = new char[maxLength]) == NULL)
    {
        return FALSE;
    }
    memset(buf,0,maxLength);
    rtn = m_connection.Receive(buf, maxLength, &realLength);
    (*data).Format(_T("%s"), buf);
    delete[] buf;
    if (rtn != 0)
    {
	    DispError(m_connection.GetLastError());
	    return FALSE;
    }
	return TRUE;
}

//==========================================//
///<summary>Function: SetSendMonitor</summary>
//==========================================//
void CMainDialog::SetSendMonitor(CString msg)
{
    CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_SEND);
    CString sendMsg;
    pEdit->GetWindowText(sendMsg);
    //add return symbol into msg.
    if (sendMsg != "")
    {
        sendMsg += "\r\n";
    }
    sendMsg += msg;

    //get the count of rows(return symbol),
    //cut off the old row when rows count > 100.
    int lineCount = 0;
    int lF        = 0;
    while (sendMsg.Find(0x0A, lF) != -1)
    {
        lF = sendMsg.Find(0x0A, lF) + 1;
        lineCount ++;
    }
    if (lineCount >= MAX_LINES)
    {
        CutLeft((char)10, &sendMsg);
    }
    //set to display.
    pEdit->SetWindowText(sendMsg);
    pEdit->LineScroll(lineCount);
}
//==========================================//
/// Function: SetReceiveMonitor
//==========================================//
void CMainDialog::SetReceiveMonitor(CString data)
{
    CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT_RCV);
    CString rcvData;
    pEdit->GetWindowText(rcvData);
    //cut off the terminator into data.
    data.Replace(10, 0);
    data.Format(_T("%s"), (LPSTR)(LPCTSTR)data);
    //add return in data.
    if (rcvData != "")
    {
        rcvData += "\r\n";
    }
    rcvData += data;

    //get the count of return symbol,
    //cut off the old row when rows count > 100.
    int lineCount = 0;
    int lF = 0;
    while (rcvData.Find(0x0A, lF) != -1)
    {
        lF = rcvData.Find(0x0A, lF) + 1;
        lineCount ++;
    }
    if (lineCount >= MAX_LINES)
    {
        CutLeft((char)10, &rcvData);
    }
    //set to display.
    pEdit->SetWindowText(rcvData);
    pEdit->LineScroll(lineCount);
}
//==========================================//
/// <summary> Function: DispError </summary>
///the errorID is received from tmctl.
///get the errorMsg corresponding the errorID.
//==========================================//
void CMainDialog::DispError(int errorID)
{
    CWnd* pWnd = GetDlgItem(IDC_EDIT_ERR);
    if (errorID == 0)
    {
        pWnd->SetWindowText("getting detail error failed.");
        return;
    }
    int n = 0;
    while (2 << n != errorID)
    {
        n ++;
    }
    //set errorMsg to display.
    pWnd->SetWindowText(errorMsg[n]);
}
void CMainDialog::DispError(CString errorInfo)
{
    //set errorMsg to display.
    CWnd* pWnd = GetDlgItem(IDC_EDIT_ERR);
    pWnd->SetWindowText(errorInfo);    
}

//==========================================//
/// <summary> Function: GetData </summary>
//==========================================//
void CMainDialog::GetItemData()
{
    int n;
    int rtn;
    CString msg;

    UpdateData();
    //----------------------#print title(Function) when getting data once#
    CWnd* pWnd = GetDlgItem(IDC_BUTTON_GETDATA_S);
    if (IsDlgButtonChecked(IDC_CHECK_SAVE) 
        && !m_sFileName.IsEmpty()//when file name is null, do not save.
        && pWnd->IsWindowEnabled())
    {
        //print titles(function) when saveBox is checked.
          ofstream csvFile(m_sFileName, ios::app);
        if (csvFile.fail())
        {
            MessageBox("file can not open!", "Error", MB_ICONERROR | MB_OK);
            return;
        }

        //out put current time.
        SYSTEMTIME CurTime;
        GetLocalTime(&CurTime);
        csvFile << "Date: " << CurTime.wYear << "/" << CurTime.wMonth;
        csvFile << "/" << CurTime.wDay << ",";

        int fLoop = IDC_COMBO_F1;
        CString function;
        CComboBox* pCombo;
        for (n = 0; n < atoi(m_sComboItems); n ++)
        {
	        pCombo = (CComboBox*)GetDlgItem(fLoop ++);
            pCombo->GetWindowText(function);
            csvFile << function << ",";
        }
        csvFile << "\n";
        csvFile.close();
    }

    msg = ":NUMERIC:NORMAL:VALUE?";

    //----------------------#send message#
    SetSendMonitor(msg);

    //###ASCII:TmcSend(); FLOAT:TmcSendBuLength()###
    if (IsDlgButtonChecked(IDC_RADIO_ASC))
    {
        rtn = m_connection.Send(msg);
    }
    else
    {
        rtn = m_connection.SendByLength(msg, msg.GetLength());
    }
    if (rtn != 0)
    {
	    DispError(m_connection.GetLastError());
	    return;
    }

    //----------------------#receive values#
    char* buf;
    int maxLength;
    int realLength;
    CString value;
    CEdit* pEdit;
    int dLoop = IDC_EDIT_D1;
    CString data;

    if (IsDlgButtonChecked(IDC_RADIO_ASC))
    {
        //----------------------#receive values by ASCII#
        //###ASCII:TmcReceive()###
        UpdateData(TRUE);
        maxLength = 15 * atoi(m_sComboItems);
        if ((buf = new char[maxLength]) == NULL)
        {
            return;
        }
        memset(buf, 0, maxLength);
        rtn = m_connection.Receive(buf, maxLength, &realLength);
        value.Format(_T("%s"), buf);
        delete[] buf;
        if (rtn != 0)
        {
	        DispError(m_connection.GetLastError());
	        return;
        }
        SetReceiveMonitor(value);
    }
    else
    {
        //----------------------#receive values by Float#
        //###FLOAT:TmcReceiveBlock()###
        rtn = m_connection.ReceiveBlockHeader(&maxLength);
        if (maxLength < 1)
        {
            return;
        }
        maxLength ++;//see tmctl's help
        if ((buf = new char[maxLength]) == NULL)
        {
            return;
        }

        int isEnd = 0;
        char bytes[sizeof(float)];
        float floatBuf;
		CString outputValue;
        while (isEnd == 0)
        {
            memset(buf, 0, maxLength);
            rtn = m_connection.ReceiveBlockData(buf, maxLength, &realLength, &isEnd);
            if (rtn != 0)
            {
                delete[] buf;
	            DispError(m_connection.GetLastError());
	            return;
            }
			for (n=0; n<realLength-1; n++)
			{
                data.Format(_T("%02X"), (unsigned char)buf[n]);
				outputValue = outputValue + data;
			}
            //converse the char format and copy as float.
            for (n=0; n<realLength/4; n++)
            {
                bytes[3] = buf[n * 4];
                bytes[2] = buf[n * 4 + 1];
                bytes[1] = buf[n * 4 + 2];
                bytes[0] = buf[n * 4 + 3];
                memcpy(&floatBuf, bytes, sizeof(float));
                data.Format(_T("%e"), floatBuf);
                value += data + ',';
            }
        }
        delete[] buf;
		SetReceiveMonitor(outputValue);
    }

    //----------------------#display data and output when saveBox checked#
    if (IsDlgButtonChecked(IDC_CHECK_SAVE) && !m_sFileName.IsEmpty())
    {
          ofstream csvFile(m_sFileName, ios::app);
        if (csvFile.fail())
        {
            MessageBox("file can not open!", "Error", MB_ICONERROR | MB_OK);
            return;
        }

        //out put current time.
        SYSTEMTIME CurTime;
        GetLocalTime(&CurTime);
        csvFile << "Time: " << CurTime.wHour << ":" <<CurTime.wMinute << ":";

        //csvFile << second.Format("%5.3lf",msec);
		CString msec;
		msec.Format("%d.%03d", CurTime.wSecond, CurTime.wMilliseconds);
        csvFile << (LPCSTR)msec << ",";

        for (n=0; n<atoi(m_sComboItems); n++)
        {
            //set display
            data = CutLeft(',', &value);
	        pEdit = (CEdit*)GetDlgItem(dLoop++);
            pEdit->SetWindowText(data);
            //output data
            csvFile << data << ",";
        }
        csvFile << "\n";
        csvFile.close();
    }
    else
    {
        for (n=0; n<atoi(m_sComboItems); n++)
        {
            //set display
            data = CutLeft(',', &value);
	        pEdit = (CEdit*)GetDlgItem(dLoop++);
            pEdit->SetWindowText(data);
        }
    }
}

//==========================================//
/// <summary> Function: GetRanges </summary>
//==========================================//
bool CMainDialog::GetRanges()
{
    int n;
	CString msg;
    CString terminal;

    m_comboU.ResetContent();
    m_comboI.ResetContent();
    //UpdateData(FALSE); //used for DDX refresh

	///#set voltage list#
	n = 0;
	while (!voltageList[nCrestFactor][n].IsEmpty())
	{
		m_comboU.AddString(voltageList[nCrestFactor][n]);
		n++;
	}
	m_comboU.AddString(rangeListAuto);

	///#set current list#
	n = currenttop;
	while (n <= currentbottom)
	{
		if(currentList[nCrestFactor][n].IsEmpty())
			break;
		m_comboI.AddString(currentList[nCrestFactor][n]);
		n++;
	}

	///#set Externnal current list#
	if(ExtOption > 0){
		n = extcurrtop;
		while (n<=extcurrbottom)
		{
			if(extcurrList[nCrestFactor][n].IsEmpty())
				break;
			m_comboI.AddString(extcurrList[nCrestFactor][n]);
			n++;
		}
	}
	m_comboI.AddString(rangeListAuto);	

    //--------------------#Get Voltage Range Settings#
    //###":VOLT:RANG:ELEM1 3.00E+00;ELEM2 1.00E+03"###
    CString range;
    double doubleRange;

    msg = ":INPUT:VOLTAGE:RANGE?";
    SetSendMonitor(msg);
    if (!QueriesData(60, msg, &range))
    {
        return FALSE;
    }
    SetReceiveMonitor(range);
    range = CutLeft((char)10, &range);//cut left with LF.
    /*************************************************************/
    CString auto_tem;
    //double doubleRange;
    auto_tem="";
    msg = ":INPUT:VOLTAGE:AUTO?";
    SetSendMonitor(msg);
    if (!QueriesData(60, msg, &auto_tem))
    {
        return FALSE;
    }
    SetReceiveMonitor(auto_tem);
    auto_tem = CutLeft((char)10, &auto_tem);//cut left with LF.
	/*************************************************************/

    if (auto_tem == "1")
    {
        m_comboU.SetWindowText(rangeListAuto);
    }
    else
    {
        doubleRange = atof(range);
        range.Format(_T("%f"), doubleRange);
        range.TrimRight("0");
        range.TrimRight(".");
        m_comboU.SetWindowText(range + "V");
    }

    //----------------------#Get Current Range Settings#
    //###":CURR:RANG:ELEM5 3.00E+00;ELEM6 1.00E-03"###
    msg = ":INPUT:CURRENT:RANGE?";
    SetSendMonitor(msg);
    if (!QueriesData(60, msg, &range))
    {
        return FALSE;
    }
    SetReceiveMonitor(range);
    range = CutLeft((char)10, &range);//cut left with LF.

	//wether have external current sensor input
	CString external;
	external.Empty();
	external=CutLeft(',',&range);  //cut left with ",".

    /* * * * ****************************************************/
    CString tem_auto;
    //double doubleRange;
    tem_auto="";
    msg = ":INPUT:CURRENT:AUTO?";
    SetSendMonitor(msg);
    if (!QueriesData(60, msg, &tem_auto))
    {
        return FALSE;
    }
    SetReceiveMonitor(tem_auto);
    tem_auto = CutLeft((char)10, &tem_auto);//cut left with LF.
	/* * * * ****************************************************/

    if (tem_auto == "1")
	{
        m_comboI.SetWindowText(rangeListAuto);
    }
	else
	{
        doubleRange = atof(range);
		if(external=="EXT"||external=="EXTERNAL"){
    	    if (doubleRange >= 1 || ( nCrestFactor == CF_6 && doubleRange == 0.5 )) {
				range.Format(_T("%f"), doubleRange);
				range.TrimRight("0");
				range.TrimRight(".");
				m_comboI.SetWindowText(range + "V");
			}
			else{
				range.Format(_T("%f"), doubleRange * 1000);
				range.TrimRight("0");
				range.TrimRight(".");
				m_comboI.SetWindowText(range + "mV");
			}
		}
		else{
	        if (doubleRange >= 1 || doubleRange == 0.5 || doubleRange == 0.25){
				range.Format(_T("%f"), doubleRange);
				range.TrimRight("0");
				range.TrimRight(".");
				m_comboI.SetWindowText(range + "A");
			}
			else{
				range.Format(_T("%f"), doubleRange * 1000);
				range.TrimRight("0");
				range.TrimRight(".");
				m_comboI.SetWindowText(range + "mA");
			}
		}
    }
    return TRUE;
}
//==========================================//
//RangeSettings
//==========================================//
void CMainDialog::RangeListSettings()
{

	if(modelType == "WT310E" || modelType == "WT310"){
		currenttop = WT310_CURRENT_TOP;
		currentbottom = WT310_CURRENT_BOTTM;
	}
	else if(modelType == "WT310EH" || modelType == "WT310HC"){
		currenttop = WT310HC_CURRENT_TOP;
		currentbottom = WT310HC_CURRENT_BOTTM;
	}
	else if(modelType == "WT332E" || modelType == "WT333E" || modelType == "WT332" || modelType == "WT333" ){
		currenttop = WT330_CURRENT_TOP;
		currentbottom = WT330_CURRENT_BOTTM;
	}
	
	if(ExtOption == EX1){
		extcurrtop =  EX1_CURRENT_TOP;
		extcurrbottom = EX1_CURRENT_BOTTM;
	}
	else if(ExtOption == EX2){
		extcurrtop = EX2_CURRENT_TOP;
		extcurrbottom = EX2_CURRENT_BOTTM;
	}
}

//==========================================//
///Set Range
//==========================================//
void CMainDialog::OnButtonSetRange() 
{
	int rtn_tmp;
	rtn_tmp=-1;
	//----------------------#Get the Selected Element#
    UpdateData(TRUE);
    CString sENo;           //format element Number to CString.
    sENo.Format(_T("%d"),m_iRadioElement + 1);
	//----------------------#Send Voltage Range#
	CString msg;
	m_comboU.GetWindowText(msg);
	if(msg != "AUTO")
	{
		msg = ":INPUT:VOLTAGE:RANGE " + msg;
	}
    else 
	{
		msg = ":INPUT:VOLT:AUTO ON";
	}
	SetSendMonitor(msg);
    int rtn = m_connection.Send(msg);
    if(rtn != 0)
    {
	    DispError(m_connection.GetLastError());
	    //when setting failed, resume the original value.
	    GetRanges();
    }

	//----------------------#Send Current Range#
	CString Current_Sen;
	m_comboI.GetWindowText(msg);
    Current_Sen=msg;
    rtn_tmp=Current_Sen.Find('V');

    if(msg != "AUTO")
	{
		if(rtn_tmp > 0)
		{
			msg = ":INPUT:CURRENT:RANGE EXTERNAL," + msg;
		}
		else
		{
			msg = ":INPUT:CURRENT:RANGE " + msg;
		}
	}
	else
	{
       msg = ":INPUT:CURRENT:AUTO ON";
	}
	SetSendMonitor(msg);
    rtn = m_connection.Send(msg);
    if(rtn != 0)
    {
	    DispError(m_connection.GetLastError());
	    //when setting failed, resume the original value.
	    GetRanges();
    }
    GetRanges();
}

//===========================================//
/// <summary>
/// Function: Get Update Rate
/// </summary>
//===========================================//
void CMainDialog::GetUpdateRate() 
{
    ///#get harmonics state#
    CString msg;
	CString value;
	value == "";
    ///#set updateRate combo list#
    m_comboR.ResetContent();
    CWnd* pWnd;

    pWnd = GetDlgItem(IDC_BUTTON_SETRATE);
    pWnd->EnableWindow(TRUE);
    pWnd = GetDlgItem(IDC_COMBOR);
    pWnd->EnableWindow(TRUE);
	int n = 0;
	int updateRateBottom = (-1 == modelType.Find("E")) ? 5 : 8;
	while (n <= updateRateBottom)
//  while(!updateRateList[n].IsEmpty())
    {
        m_comboR.AddString(updateRateList[n]);
        n++;
    }

    msg = ":RATE?";
    SetSendMonitor(msg);
    if (!QueriesData(30, msg, &value))
    {
        return;
    }
    SetReceiveMonitor(value);
    value = CutLeft((char)10, &value); //cut left with LF.

	if( value == "AUTO" )
	{
		m_comboR.SetWindowText(value);
		return;
	}

    double doubleRate = atof(value);
    if(doubleRate < 1)
    {
        //when "ms" unit, multiply 1k.
        value.Format(_T("%.0f"), doubleRate * 1000);
        m_comboR.SetWindowText(value + "ms");
    }
    else
    {
        value.Format(_T("%.0f"), doubleRate);
        m_comboR.SetWindowText(value + "s");
    }
}

//==========================================//
///Set UpdateRate
//==========================================//
void CMainDialog::OnButtonSetRate() 
{
    CString value;
    CString msg;

	//Send Command.
    m_comboR.GetWindowText(value);
    msg = ":RATE " + value;
	SetSendMonitor(msg);
	int rtn = m_connection.Send(msg);
    if(rtn != 0)
    {
	    DispError(m_connection.GetLastError());
        //when setting failed, resume the original value.
        GetUpdateRate();
    }
	GetUpdateRate();
}

//==========================================//
///Test Command Send
//==========================================//
void CMainDialog::OnButtonSendCmd() 
{
    UpdateData(TRUE);
    if(m_sEditTest == "")
    {
        return;
    }
	SetSendMonitor(m_sEditTest);
	if(m_sEditTest.Find("?") == -1)
    {
        int rtn;
	    //Send Command.
	    rtn = m_connection.Send(m_sEditTest);
        if(rtn != 0)
        {
	        DispError(m_connection.GetLastError());
        }
    }
    else
    {
        CString data;
        if (!QueriesData(1000, m_sEditTest, &data))
        {
            return;
        }
	    SetReceiveMonitor(data);
    }
}

//==========================================//
///Getting Error Information
//==========================================//
void CMainDialog::OnButtonGetError() 
{
    //----------------------#queries error from instrument#
    CString msg;
    CString errInfo;
    msg = ":STATUS:ERROR?";
    SetSendMonitor(msg);
    if(!QueriesData(150, msg, &errInfo))
    {
        return;
    }
    //cut off the return.
    errInfo = errInfo.Left(errInfo.Find((char)10));
    SetReceiveMonitor(errInfo);
    DispError(errInfo);
}

//==========================================//
///Set Header On/Off
//==========================================//
void CMainDialog::OnButtonHeader() 
{
    CString header;
    CString msg;
    //----------------------#queries header status#
    msg = ":COMMUNICATE:HEADER?";
    SetSendMonitor(msg);
    if(!QueriesData(25, msg, &header))
    {
        return;
    }
    SetReceiveMonitor(header);
    header = CutLeft((char)10, &header);//cut left with LF.

    //----------------------#set header status#
    if(header == "1")
    {
        msg = ":COMMUNICATE:HEADER OFF";
    }
    else
    {
        msg = ":COMMUNICATE:HEADER ON";
    }
    SetSendMonitor(msg);
    int rtn = m_connection.Send(msg);
    if(rtn != 0)
    {
	    DispError(m_connection.GetLastError());
	    return;
    }
}

//==========================================//
///Set Verbose On/Off
//==========================================//
void CMainDialog::OnButtonVerbose() 
{
    CString verbose;
    CString msg;
    //----------------------#queries verbose status#
    msg = ":COMMUNICATE:VERBOSE?";
    SetSendMonitor(msg);
    if(!QueriesData(25, msg, &verbose))
    {
        return;
    }
    SetReceiveMonitor(verbose);
    verbose = CutLeft((char)10, &verbose);//cut left with LF.

    //----------------------#set verbose status#
    if(verbose == "1")
    {
        msg = ":COMMUNICATE:VERBOSE OFF";
    }
    else
    {
        msg = ":COMMUNICATE:VERBOSE ON";
    }
    SetSendMonitor(msg);
    int rtn = m_connection.Send(msg);
    if(rtn != 0)
    {
	    DispError(m_connection.GetLastError());
	    return;
    }
}

//==========================================//
///System Reset
//==========================================//
void CMainDialog::OnButtonRst() 
{
    int reset = MessageBox("System will be All Reset, continue?", "Confirm", MB_OKCANCEL|MB_ICONWARNING);
    if(reset == IDCANCEL)
    {
        return;
    }
    else
    {
        CString msg = "*RST";
	    SetSendMonitor(msg);
	    int rtn = m_connection.Send(msg);
        if(rtn != 0)
        {
	        DispError(m_connection.GetLastError());
	        return;
        }
        UpdateData();
		GetUpdateRate();
        GetRanges();
		ReadItemSettings();
    }
}

//=============================================//
///Function: ReadItemSettings
//=============================================//
void CMainDialog::ReadItemSettings() 
{
	CString msg;
    CString buf;
    CComboBox* pCombo;
	CString fun_msg;
	int pos;
	pos=-1;

    //----------------------#get ASCII/BINARY#
    msg = ":NUMERIC:FORMAT?";
    SetSendMonitor(msg);
    if(!QueriesData(30, msg, &buf))
    {
        return;
    }
    SetReceiveMonitor(buf);
    buf = CutLeft((char)10, &buf);  //cut left with LF.
    //----------------------#set ASCII/BINARY option#
    if(buf.Find("ASC") != -1)
    {
        CheckDlgButton(IDC_RADIO_ASC, BST_CHECKED);
        CheckDlgButton(IDC_RADIO_BIN, BST_UNCHECKED);
    }
    else
    {
        CheckDlgButton(IDC_RADIO_ASC, BST_UNCHECKED);
        CheckDlgButton(IDC_RADIO_BIN, BST_CHECKED);
    }
    //----------------------#get item count#

    msg = ":NUMERIC:NORMAL:NUMBER?";
    SetSendMonitor(msg);
    if(!QueriesData(30, msg, &buf))
    {
        return;
    }
    SetReceiveMonitor(buf);
    buf = CutLeft((char)10, &buf);   //cut left with LF.

    //----------------------#set item count combo#
    pCombo = (CComboBox*)GetDlgItem(IDC_COMBO_ITEMS);
    if(atoi(buf) > MAX_ITEM)
    {
        CString maxItem;
        maxItem.Format(_T("%d"), MAX_ITEM);
        ComboListSel(pCombo, maxItem);
    }
    else
    {
        ComboListSel(pCombo, buf);
    }
    OnSelchangeComboItems();

    msg = ":NUMERIC:NORMAL?";
 
    SetSendMonitor(msg);
    if(!QueriesData(30 + 30*atoi(buf), msg, &buf))
    {
        return;
    }
    SetReceiveMonitor(buf); 
    buf = CutLeft((char)10, &buf);      //cut left with LF.
    //cut off the item number(item count) portion.
    CutLeft(';', &buf);

    //----------------------#set item settings to be display#
    UpdateData(TRUE);
    CString itemBuf;
    CString element;
    int fLoop = IDC_COMBO_F1;
    int eLoop = IDC_COMBO_E1;
    int oLoop = IDC_COMBO_O1;
    int n;

    for(n=0; n<atoi(m_sComboItems); n++)
    {
		itemBuf = CutLeft(';', &buf);
		fun_msg = CutLeft(',', &itemBuf);
		/************ Replace *************/
		if(fun_msg == "LAMB")
		   {fun_msg = "LAMBDA";}
		else if(fun_msg == "UPP")
		   {fun_msg = "UPPEAK";}
		else if(fun_msg == "UMP")
		   {fun_msg = "UMPEAK";}
		else if(fun_msg == "IPP")
		   {fun_msg = "IPPEAK";}
		else if(fun_msg == "IMP")
		   {fun_msg = "IMPEAK";}
		else if(fun_msg == "PPP")
		   {fun_msg = "PPPEAK";}
		else if(fun_msg == "PMP")
		   {fun_msg = "PMPEAK";}
		else if(fun_msg == "URAN")
		   {fun_msg = "URANGE";}
		else if(fun_msg == "IRAN")
		   {fun_msg = "IRANGE";}
		else if(fun_msg == "PHIU")
		   {fun_msg = "PHIUK";}
		else if(fun_msg == "PHII")
		   {fun_msg = "PHIIK";}
		else if(fun_msg == "UHDF")
		   {fun_msg = "UHDFK";}
		else if(fun_msg == "IHDF")
		   {fun_msg = "IHDFK";}
		else if(fun_msg == "PHDF")
		   {fun_msg = "PHDFK";}
		/***********************************/
		pCombo = (CComboBox*)GetDlgItem(fLoop++);
        pCombo->SetWindowText(fun_msg);
		oldFuncName[n] = fun_msg;

		//#set element.#  
		pCombo = (CComboBox*)GetDlgItem(eLoop++);
		pos = -1;
		pos = FindFunPos(fun_msg);
		if(List[pos].ElementFlag)
		{
            pCombo->EnableWindow(TRUE);
			if (lastElement > 1){
				if(NORMAL_FUNCTION_TOP <= pos && pos <= NORMAL_FUNCTION_BOTTOM) {
					int nIndex = pCombo->FindString(-1,"SIGMA");
					if(nIndex == CB_ERR){
						pCombo->AddString(eList[3]);
					}
				}
				else if(HARM_FUNCTION_TOP <= pos && pos <= HARM_FUNCTION_BOTTOM) {
					int nIndex = pCombo->FindString(-1,"SIGMA");
					if(nIndex != CB_ERR){
						pCombo->DeleteString(nIndex);
					}
				}
			}
			element = CutLeft(',', &itemBuf);
			if (element == "SIGM")
			{
				element = "SIGMA";
			}
			pCombo->SetWindowText(element);
		}
		else
		{  
			pCombo->SetWindowText("");
			pCombo->EnableWindow(FALSE);
		}

		//set orders
        pos = -1;
	    pCombo = (CComboBox*)GetDlgItem(oLoop ++);
		if(HarmonicOption >= 0)
		{
			pos=FindFunPos(fun_msg);
			if(List[pos].OrderFlag)
			{
				CString temp_order;
				temp_order=CutLeft(',',&itemBuf);
				if (temp_order=="TOTAL"||temp_order=="TOT")
				{temp_order="Total";}
				pCombo->EnableWindow(TRUE);
				pCombo->SetWindowText(temp_order);
			}
			else 
			{   
				pCombo->SetWindowText("");
				pCombo->EnableWindow(FALSE);
			}
		}
		else
		{
			pCombo->SetWindowText("");
		    pCombo->EnableWindow(FALSE);
		}
	}//end for
}

//==========================================//
//Function: SendItemSettings
//==========================================//
void CMainDialog::SendItemSettings() 
{
    CString msg;
    CString state;
    int rtn;

    //----------------------#set ASCII/Float(Binary)#
    if(IsDlgButtonChecked(IDC_RADIO_ASC))
    {
        msg = ":NUMERIC:FORMAT ASCII";
    }
    else
    {
        msg = ":NUMERIC:FORMAT FLOAT";
    }
    SetSendMonitor(msg);
    rtn = m_connection.Send(msg);
    if(rtn != 0)
    {
	    DispError(m_connection.GetLastError());
	    return;
    }

    //----------------------#set items number#
    msg = ":NUMERIC:NORMAL:NUMBER " + m_sComboItems;

    SetSendMonitor(msg);
    rtn = m_connection.Send(msg);
    if(rtn != 0)
    {
	    DispError(m_connection.GetLastError());
	    return;
    }

    //----------------------#send message detail#
    int n;
    CString itemIndex;
    CString param;
    CComboBox* pCombo;
    int fLoop = IDC_COMBO_F1;
    int eLoop = IDC_COMBO_E1;
    int oLoop = IDC_COMBO_O1;

    msg = ":NUMERIC:NORMAL:";
    for(n=0; n<atoi(m_sComboItems); n++)
    {
        itemIndex.Format(_T("%d"), n + 1);

        //set function parameter into message.
        pCombo = (CComboBox*)GetDlgItem(fLoop++);
        pCombo->GetWindowText(param);
        msg = msg + "ITEM" + itemIndex + " " + param;

        //set element parameter into message.
        pCombo = (CComboBox*)GetDlgItem(eLoop++);
        pCombo->GetWindowText(param);
		if(pCombo->IsWindowEnabled() == TRUE)
		{
        msg = msg + "," + param;
		}

        //set order parameter into message, if have.
        pCombo = (CComboBox*)GetDlgItem(oLoop++);
        pCombo->GetWindowText(param);
		if(pCombo->IsWindowEnabled() == TRUE)
        {
            msg = msg + "," + param;
        }

        //set separator into message.
        if (n != atoi(m_sComboItems) - 1)
        {
            msg = msg + ";";
        }
    }
    msg.Replace("SGM", "SIGM");//sending as "SIGM" when display as "SGM".

    SetSendMonitor(msg);
    rtn = m_connection.Send(msg);
    if(rtn != 0)
    {
	    DispError(m_connection.GetLastError());
	    return;
    }
}

//=============================================//
///Read Item Settings
//=============================================//
void CMainDialog::OnButtonGetItems() 
{
	ReadItemSettings();
}

//==========================================//
///Send Item Settings
//==========================================//
void CMainDialog::OnButtonSetItems() 
{
    SendItemSettings();
}

//==========================================//
//Function: EnableItems
//==========================================//
void CMainDialog::EnableItems(bool isEnable)
{
    GetDlgItem(IDC_BUTTON_SETRATE)->EnableWindow(isEnable);
    GetDlgItem(IDC_COMBOR)->EnableWindow(isEnable);
    GetDlgItem(IDC_BUTTON_SETRANGE)->EnableWindow(isEnable);
    GetDlgItem(IDC_BUTTON_SENDCMD)->EnableWindow(isEnable);
    GetDlgItem(IDC_BUTTON_GETERR)->EnableWindow(isEnable);
    GetDlgItem(IDC_BUTTON_RST)->EnableWindow(isEnable);
    GetDlgItem(IDC_BUTTON_HEADER)->EnableWindow(isEnable);
    GetDlgItem(IDC_BUTTON_VERBOSE)->EnableWindow(isEnable);

    GetDlgItem(IDC_BUTTON_GETITEMS)->EnableWindow(isEnable);
    GetDlgItem(IDC_BUTTON_SETITEMS)->EnableWindow(isEnable);
    GetDlgItem(IDC_COMBO_ITEMS)->EnableWindow(isEnable);
    GetDlgItem(IDC_RADIO_ASC)->EnableWindow(isEnable);
    GetDlgItem(IDC_RADIO_BIN)->EnableWindow(isEnable);

    GetDlgItem(IDC_BUTTON_GETDATA_S)->EnableWindow(isEnable);
    GetDlgItem(IDC_BUTTON_GETDATA_R)->EnableWindow(isEnable);
    GetDlgItem(IDC_BUTTON_GETDATA_T)->EnableWindow(isEnable);
    GetDlgItem(IDC_EDIT_TMR)->EnableWindow(isEnable);
    GetDlgItem(IDC_CHECK_SAVE)->EnableWindow(isEnable);
    GetDlgItem(IDC_EDIT_FILE)->EnableWindow(isEnable);
}

//==========================================//
//Timer Event
//==========================================//
void CMainDialog::OnTimer(UINT nIDEvent)
{
    if(nIDEvent == 1)   //get data by update rate.
    {
        CString eesr;
        CString msg = ":STATUS:EESR?";
        SetSendMonitor(msg);
        if(!QueriesData(20, msg, &eesr))
        {
            return;
        }
        SetReceiveMonitor(eesr);
        eesr = CutLeft((char)10, &eesr);  //cut left with LF.

        if((atoi(eesr) & 0X01) == 1)
        {
            GetItemData();
        }
    }
    else if(nIDEvent == 2)  //get data by timer.
    {
        GetItemData();
        return;
    }
}

//==========================================//
///GetData Single
//==========================================//
void CMainDialog::OnButtonGetDataS() 
{
    SendItemSettings();
    GetItemData();
}

//==========================================//
///GetData by UpdateRate
//==========================================//
void CMainDialog::OnButtonGetDataR() 
{
    CString caption;
    CWnd* pWnd;
    pWnd = GetDlgItem(IDC_BUTTON_GETDATA_R);
    pWnd->GetWindowText(caption);
    //----------------------#resume all#
    if(caption == "STOP")
    {
        KillTimer(TIMER_1);
        pWnd->SetWindowText("    Get Data      (Update Rate)");
        EnableItems(TRUE);
        //resume fileNameInputText.
        if(!IsDlgButtonChecked(IDC_CHECK_SAVE))
        {
            pWnd = (CButton*)GetDlgItem(IDC_EDIT_FILE);
            pWnd->EnableWindow(FALSE);
        }
    }
    //----------------------#getting datas#
    else
    {
        UpdateData(TRUE);
        if(IsDlgButtonChecked(IDC_CHECK_SAVE) && !m_sFileName.IsEmpty())
        {
            //print titles(function) once when saveBox is checked
			ofstream csvFile(m_sFileName, ios::app);
            if(csvFile.fail())
            {
                MessageBox("file can not open!", "Error", MB_ICONERROR | MB_OK);
                return;
            }

            //out put current time.
            SYSTEMTIME CurTime;
            GetLocalTime(&CurTime);
            csvFile << "Date: " << CurTime.wYear << "/" << CurTime.wMonth;
            csvFile << "/" << CurTime.wDay << ",";

            int fLoop = IDC_COMBO_F1;
            int n;
            CString function;
            CComboBox* pCombo;
            for(n=0; n<atoi(m_sComboItems); n++)
            {
	            pCombo = (CComboBox*)GetDlgItem(fLoop++);
                pCombo->GetWindowText(function);
                csvFile << function << ",";
            }
            csvFile << "\n";
            csvFile.close();
        }
        SendItemSettings();

        //reset filter1.
        CString msg = ":STATUS:FILTER1 FALL";
        SetSendMonitor(msg);
	    int rtn = m_connection.Send(msg);
        if(rtn != 0)
        {
	        DispError(m_connection.GetLastError());
	        return;
        }
        //*******************************************
		CString eesr;
        msg = ":STATUS:EESR?";
        SetSendMonitor(msg);
        if(!QueriesData(20, msg, &eesr))
        {
            return;
        }
        SetReceiveMonitor(eesr);
		//*******************************************
        //reset other controls' display.
        EnableItems(FALSE);
        pWnd->EnableWindow(TRUE);
        pWnd->SetWindowText("STOP");
        
        //set timer interval and start getting data.
        CWnd::SetTimer(TIMER_1,20,NULL);
    }
}

//==========================================//
///GetData by Timer
//==========================================//
void CMainDialog::OnButtonGetDataT() 
{
    CString text;
    CWnd* pWnd;
    pWnd = GetDlgItem(IDC_BUTTON_GETDATA_T);
    pWnd->GetWindowText(text);
    //----------------------#resume all#
    if(text == "STOP")
    {
        KillTimer(TIMER_2);
        pWnd->SetWindowText("Get Data (Timer)");
        EnableItems(TRUE);
        //resume fileNameInputText.
        if(!IsDlgButtonChecked(IDC_CHECK_SAVE))
        {
            pWnd = (CButton*)GetDlgItem(IDC_EDIT_FILE);
            pWnd->EnableWindow(FALSE);
        }
    }
    //----------------------#getting datas#
    else
    {
	    UpdateData(TRUE);
        if(IsDlgButtonChecked(IDC_CHECK_SAVE) && !m_sFileName.IsEmpty())
        {
            //print titles(function) once while saveBox is checked.
			ofstream csvFile(m_sFileName, ios::app);
			if(csvFile.fail())
            {
                MessageBox("file can not open!", "Error", MB_ICONERROR | MB_OK);
                return;
            }

            //out put current time.
            SYSTEMTIME CurTime;
            GetLocalTime(&CurTime);
            csvFile << "Date: " << CurTime.wYear << "/" << CurTime.wMonth;
            csvFile << "/" << CurTime.wDay << ",";

            int fLoop = IDC_COMBO_F1;
            int n;
            CString function;
            CComboBox* pCombo;
            for(n=0; n<atoi(m_sComboItems); n++)
            {
	            pCombo = (CComboBox*)GetDlgItem(fLoop ++);
                pCombo->GetWindowText(function);
                csvFile << function << ",";
            }
            csvFile << "\n";
            csvFile.close();
        }

        SendItemSettings();
        //reset other controls' display.
        EnableItems(FALSE);
        pWnd->EnableWindow(TRUE);
        pWnd->SetWindowText("STOP");

        //set timer interval and start getting data.
        pWnd = GetDlgItem(IDC_EDIT_TMR);
        pWnd->GetWindowText(text);
        int timer = atoi(text);
        if(timer < 20)
        {
            timer = 20;
            pWnd->SetWindowText("20");
        }
        CWnd::SetTimer(TIMER_2, timer, NULL);
    }
}

//##########################################//
//DISPLAY CONTROL
//##########################################//

//==========================================//
///Normal Checked
//==========================================//

//GetOption
void CMainDialog::GetOption(void)
{
    int itemIndex;
    int n;
	CComboBox* pCombo;
	CEdit* pEdit;
    int fLoop = IDC_COMBO_F1;
    int eLoop = IDC_COMBO_E1;
    int oLoop = IDC_COMBO_O1;
    int dLoop = IDC_EDIT_D1;
	int G5;
	int EX;
    CString opt;
    CString msg = "*OPT?";

    SetSendMonitor(msg);
    if(!QueriesData(50, msg, &opt))
    {
        return;
    }
    SetReceiveMonitor(opt);

    //Get Harmonics option
    G5 = -1;
	G5=opt.Find("G5");
	HarmonicOption = G5;

    //Get Ext option
	EX = -1;
	if(opt.Find("EX1") >= 0){
		EX = EX1;
	}
	else if(opt.Find("EX2") >= 0){
		EX = EX2;
	}
	ExtOption = EX;

    for(itemIndex=0; itemIndex<MAX_ITEM; itemIndex++)
    {
        //----------------------#set function comboBoxes#
	    pCombo = (CComboBox*)GetDlgItem(fLoop ++);
        pCombo->ResetContent();
		for(n=NORMAL_FUNCTION_TOP; n<=NORMAL_FUNCTION_BOTTOM; n++)
		{
			pCombo->AddString(List[n].FunctionName);
		}

		//Add Harmonics funcion
		if(HarmonicOption >= 0)
		{
			for(n=HARM_FUNCTION_TOP; n<=HARM_FUNCTION_BOTTOM; n++)
				pCombo->AddString(List[n].FunctionName);
		}

        pCombo->SetCurSel(0);

        //-------------#set elememt comboBoxes#
	    pCombo = (CComboBox*)GetDlgItem(eLoop ++);
        pCombo->ResetContent();
        for(n=0; n<lastElement; n++)
        {
            pCombo->AddString(eList[n]);
        }
        if (lastElement != 1)
        {
            pCombo->AddString(eList[3]);
        }
        pCombo->SetCurSel(0);

        //----------------------#set order comboBoxes#
	    pCombo = (CComboBox*)GetDlgItem(oLoop ++);
		if(HarmonicOption >= 0)
		{
			pCombo->ResetContent();
			pCombo->EnableWindow(TRUE);

			for(n=0; n<=MAX_ORDER; n++)
			{
				pCombo->AddString(oList[n]);

			}
			pCombo->SetCurSel(0);
		}
		else
		{
		    pCombo->EnableWindow(FALSE);
		}
        //----------------------#set data editBoxes#
	    pEdit = (CEdit*)GetDlgItem(dLoop ++);
        pEdit->SetWindowText("");
    }
    //----------------------#get settings from instrument#
}

//==========================================//
///DataSave Box Checked
//==========================================//
void CMainDialog::OnCheckSave() 
{
    CWnd* pWnd = GetDlgItem(IDC_EDIT_FILE);
    if(IsDlgButtonChecked(IDC_CHECK_SAVE))
    {
        pWnd->EnableWindow(TRUE);
    }
    else
    {
        pWnd->EnableWindow(FALSE);
    }
}

//==========================================//
///Items Count Changed
//==========================================//
void CMainDialog::OnSelchangeComboItems()
{
    int n;
	CWnd* pWndCtrl;
	CString fun_msg;
	int pos;
	UpdateData();
	//--------#set to ReadOnly(TRUE/FALSE)#
    int fLoop = IDC_COMBO_F1;
    int eLoop = IDC_COMBO_E1;
    int oLoop = IDC_COMBO_O1;
    int dLoop = IDC_EDIT_D1;
    fun_msg="";
	for(n=0; n<atoi(m_sComboItems); n++)
	{
		GetDlgItem(fLoop)->EnableWindow(TRUE);
		GetDlgItemText(fLoop,fun_msg);
		fLoop++;
		//#set element.#  
		pos = -1;
		pos = FindFunPos(fun_msg);
		if(List[pos].ElementFlag)
		{
			GetDlgItem(eLoop++)->EnableWindow(TRUE);
		}
		else 
		{
		    GetDlgItem(eLoop++)->EnableWindow(FALSE);
		}
		//#set Order.# 
		if(HarmonicOption >= 0)
		{
			if(List[pos].OrderFlag) 
			{
			pWndCtrl = GetDlgItem(oLoop++);
			pWndCtrl->EnableWindow(TRUE);
			}
			else 
			{
				pWndCtrl = GetDlgItem(oLoop++);
				pWndCtrl->EnableWindow(FALSE);
			}
		}
		else  
		{
			pWndCtrl = GetDlgItem(oLoop++);
			pWndCtrl->EnableWindow(FALSE);
		}

	    GetDlgItem(dLoop++)->EnableWindow(TRUE);
	}
	while(n < MAX_ITEM)
	{
	    pWndCtrl = GetDlgItem(fLoop++);
		pWndCtrl->EnableWindow(FALSE);
	    pWndCtrl = GetDlgItem(eLoop++);
		pWndCtrl->EnableWindow(FALSE);
	    pWndCtrl = GetDlgItem(oLoop++);
		pWndCtrl->EnableWindow(FALSE);
	    pWndCtrl = GetDlgItem(dLoop++);
		pWndCtrl->EnableWindow(FALSE);
		n++;
	}
}

//==========================================//
///Clear Send Monitor
//==========================================//
void CMainDialog::OnButtonSclr() 
{
    CWnd* pWnd = GetDlgItem(IDC_EDIT_SEND);
    pWnd->SetWindowText("");
}

//==========================================//
///Clear Receive Monitor
//==========================================//
void CMainDialog::OnButtonRclr() 
{
    CWnd* pWnd = GetDlgItem(IDC_EDIT_RCV);
    pWnd->SetWindowText("");
}

//==========================================//
///Change element combobox and order combobox 
///state base on Function_selected_ change
//==========================================//
void CMainDialog::FCombo_SelectedIndexChanged(int fcomb, int ecomb, int ocomb, CString Funbuf)
{
	if(oldFuncName[fcomb - IDC_COMBO_F1] == Funbuf)
		return;
	else
		oldFuncName[fcomb - IDC_COMBO_F1] = Funbuf;

	CComboBox* pCombo_f;
	CComboBox* pCombo_e;
	CComboBox* pCombo_o;
	int pos = -1;

	pCombo_f = (CComboBox*)GetDlgItem(fcomb);
	pCombo_e = (CComboBox*)GetDlgItem(ecomb);
	pCombo_o = (CComboBox*)GetDlgItem(ocomb);
   
	pos = FindFunPos(Funbuf); 
	if(pos >= 0)
	{
		if(List[pos].ElementFlag == true)
		{
			if (lastElement > 1){
				if(NORMAL_FUNCTION_TOP <= pos && pos <= NORMAL_FUNCTION_BOTTOM) {
					int nIndex = pCombo_e->FindString(-1,"SIGMA");
					if(nIndex == CB_ERR){
						pCombo_e->AddString(eList[3]);
					}
				}
				else if(HARM_FUNCTION_TOP <= pos && pos <= HARM_FUNCTION_BOTTOM) {
					int nIndex = pCombo_e->FindString(-1,"SIGMA");
					if(nIndex != CB_ERR){
						pCombo_e->DeleteString(nIndex);
					}
				}
			}
			pCombo_e->SetWindowText("1");
		    pCombo_e->EnableWindow(TRUE);
		}
		else
		{
			pCombo_e->SetWindowText("");
			pCombo_e->EnableWindow(FALSE);
		}
        
		if(HarmonicOption >= 0)
		{
			if(List[pos].OrderFlag == true)
			{
                pCombo_o->SetWindowText("Total");
				pCombo_o->EnableWindow(TRUE);
			}
			else
			{
				pCombo_o->SetWindowText("");
				pCombo_o->EnableWindow(FALSE);
			}
		}
		else
		{
			pCombo_o->SetWindowText("");
            pCombo_o->EnableWindow(FALSE);
		}
	}//end if(pos>=0)

}

void CMainDialog::OnSelchangeComboF1() 
{
    int fcomb = IDC_COMBO_F1;
    int ecomb = IDC_COMBO_E1;
    int ocomb = IDC_COMBO_O1;
	int nIndex = m_combo_f1.GetCurSel();

    CString str;
	if(nIndex != CB_ERR)
	{
		m_combo_f1.GetLBText(nIndex, str);	
	}
	FCombo_SelectedIndexChanged(fcomb, ecomb, ocomb, str);
}

void CMainDialog::OnSelchangeComboF2() 
{
    int fcomb = IDC_COMBO_F2;
    int ecomb = IDC_COMBO_E2;
    int ocomb = IDC_COMBO_O2;
	int nIndex = m_combo_f2.GetCurSel(); 

	CString str;
	if(nIndex != CB_ERR)
	{
		m_combo_f2.GetLBText(nIndex, str);	
	}
	FCombo_SelectedIndexChanged(fcomb, ecomb, ocomb, str);	
}

void CMainDialog::OnSelchangeComboF3() 
{
    int fcomb = IDC_COMBO_F3;
    int ecomb = IDC_COMBO_E3;
    int ocomb = IDC_COMBO_O3;	
	int nIndex;
	nIndex= m_combo_f3.GetCurSel(); 

	CString str;
	if(nIndex != CB_ERR)
	{
		m_combo_f3.GetLBText(nIndex, str);	
	}
	FCombo_SelectedIndexChanged(fcomb, ecomb, ocomb, str);	
}

void CMainDialog::OnSelchangeComboF4() 
{
    int fcomb = IDC_COMBO_F4;
    int ecomb = IDC_COMBO_E4;
    int ocomb = IDC_COMBO_O4;
	int nIndex = m_combo_f4.GetCurSel();  

	CString str;
	if(nIndex != CB_ERR)
	{
		m_combo_f4.GetLBText(nIndex, str);	
	}
	FCombo_SelectedIndexChanged(fcomb, ecomb, ocomb, str);	
}

void CMainDialog::OnSelchangeComboF5() 
{
    int fcomb = IDC_COMBO_F5;
    int ecomb = IDC_COMBO_E5;
    int ocomb = IDC_COMBO_O5;
	int nIndex = m_combo_f5.GetCurSel();  

	CString str;
	if(nIndex != CB_ERR)
	{
		m_combo_f5.GetLBText(nIndex, str);	
	}
	FCombo_SelectedIndexChanged(fcomb, ecomb, ocomb, str);	
}

void CMainDialog::OnSelchangeComboF6() 
{
    int fcomb = IDC_COMBO_F6;
    int ecomb = IDC_COMBO_E6;
    int ocomb = IDC_COMBO_O6;
	int nIndex = m_combo_f6.GetCurSel(); 

	CString str;
	if(nIndex != CB_ERR)
	{
		m_combo_f6.GetLBText(nIndex, str);	
	}
	FCombo_SelectedIndexChanged(fcomb, ecomb, ocomb, str);	
}

void CMainDialog::OnSelchangeComboF7() 
{
    int fcomb = IDC_COMBO_F7;
    int ecomb = IDC_COMBO_E7;
    int ocomb = IDC_COMBO_O7;
	int nIndex = m_combo_f7.GetCurSel(); 

	CString str;
	if(nIndex != CB_ERR)
	{
		m_combo_f7.GetLBText(nIndex, str);	
	}
	FCombo_SelectedIndexChanged(fcomb, ecomb, ocomb, str);	
}

void CMainDialog::OnSelchangeComboF8() 
{
    int fcomb = IDC_COMBO_F8;
    int ecomb = IDC_COMBO_E8;
    int ocomb = IDC_COMBO_O8;
	int nIndex = m_combo_f8.GetCurSel(); 

	CString str;
	if(nIndex != CB_ERR)
	{
		m_combo_f8.GetLBText(nIndex, str);	
	}
	FCombo_SelectedIndexChanged(fcomb, ecomb, ocomb, str);	
}

void CMainDialog::OnSelchangeComboF9() 
{
    int fcomb = IDC_COMBO_F9;
    int ecomb = IDC_COMBO_E9;
    int ocomb = IDC_COMBO_O9;
	int nIndex = m_combo_f9.GetCurSel();  

	CString str;
	if(nIndex != CB_ERR)
	{
		m_combo_f9.GetLBText(nIndex, str);	
	}
	FCombo_SelectedIndexChanged(fcomb, ecomb, ocomb, str);	
}

void CMainDialog::OnSelchangeComboF10() 
{
    int fcomb = IDC_COMBO_F10;
    int ecomb = IDC_COMBO_E10;
    int ocomb = IDC_COMBO_O10;
	int nIndex = m_combo_f10.GetCurSel(); 

	CString str;
	if(nIndex != CB_ERR)
	{
		m_combo_f10.GetLBText(nIndex, str);	
	}
	FCombo_SelectedIndexChanged(fcomb, ecomb, ocomb, str);	
}
